import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.List;

public class chatListController {

    @FXML
    private ListView<String> chatListView;

    @FXML
    private Button newChatButton;

    public void initialize() {
        List<String> chatContacts = Util.fetchSpokenContacts();
        chatListView.getItems().addAll(chatContacts);
    }

    @FXML
    private void handleNewChatButtonAction() {
      Util.switchToNewChatPage();
    }

    @FXML
    private void handleChatListClick() {
        String selectedContact = chatListView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            Util.switchToChatPage(selectedContact);
        }
    }
}
