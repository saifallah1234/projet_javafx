import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.List;

public class feedController {

    @FXML
    private ListView<String> feedListView;

    @FXML
    private TextField postTextField;

    @FXML
    private Button browseButton;

    @FXML
    private Button postButton;

    @FXML
    private Button backToProfileButton;

    public void initialize() {
        List<String> feedPosts = Util.fetchFeedPosts();
        feedListView.getItems().addAll(feedPosts);
    }
    @FXML
    private void handlePostButtonAction() {
        String postText = postTextField.getText();
        if (!postText.isEmpty()) {
            feedListView.getItems().add(postText);
            Util.storeFeedPost(postText);
            postTextField.clear();
        }
    }

    @FXML
    private void handleBrowseButtonAction() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Media File");
        File selectedFile = fileChooser.showOpenDialog(new Stage());
        if (selectedFile != null) {
            String filePath = selectedFile.getAbsolutePath();
            System.out.println("Selected File: " + filePath);
        }
    }

    @FXML
    private void handleBackToProfileButtonAction() {
        // Add logic to navigate back to the user's profile page
        // You can use FXMLLoader to load the profile page FXML and set it in your scene
        Util.switchToProfilePage();
    }
}
