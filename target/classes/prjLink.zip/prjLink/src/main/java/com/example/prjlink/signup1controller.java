import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.time.LocalDate;

public class SignUp1Controller {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ImageView userPhotoField;

    @FXML
    private TextField nameField;

    @FXML
    private Label nameErrorLabel;

    @FXML
    private TextField lastNameField;

    @FXML
    private Label lastNameErrorLabel;

    @FXML
    private TextField usernameField;

    @FXML
    private Label usernameErrorLabel;

    @FXML
    private TextField emailField;

    @FXML
    private Label emailErrorLabel;

    @FXML
    private DatePicker birthdayPicker;

    @FXML
    private Label birthdayErrorLabel;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label passwordErrorLabel;

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private Label confirmPasswordErrorLabel;

    @FXML
    private TextField userPhotoField;

    @FXML
    private Button browseButton;

    @FXML
    private Button nextButton;

    @FXML
    private Hyperlink signInLink;

    @FXML
    private Label userPhotoErrorLabel;

    @FXML
    private void handleNextButtonAction(ActionEvent event) {
        String name = nameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String email = emailField.getText();
        LocalDate birthday = birthdayPicker.getValue();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();
        boolean fieldsValid = Util.validateFields(name, lastName, username, email, birthday, password, confirmPassword);

        if (fieldsValid) {
            boolean switchToErrorPage = false;

            if (switchToErrorPage) {
                Util.switchToErrorPage();
            } else {
                Util.switchToSecondSignUpPage();
            }
        }
    }

    @FXML
    private void handleSignUpLinkAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("C:\Users\bechi\Downloads\prjLink\src\main\resources\com\example\prjlink\login.fxml"));
            Parent signUpPage = loader.load();

            Scene currentScene = signInLink.getScene();

            currentScene.setRoot(signUpPage);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
