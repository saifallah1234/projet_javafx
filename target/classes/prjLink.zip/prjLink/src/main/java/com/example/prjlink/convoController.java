import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.util.List;

public class ChatPageController {

    @FXML
    private ListView<Message> messageListView;

    @FXML
    private TextField messageTextField;

    @FXML
    private Button sendTextButton;

    @FXML
    private Button sendMediaButton;

    private String contactName;

    public void initialize() {
        updateContactName();
        List<Message> conversationMessages = Util.fetchConversationMessages(contactName);
        messageListView.getItems().setAll(conversationMessages);
    }

    private void updateContactName() {
        contactName = Util.fetchCurrentContact();
    }
    @FXML
    private void handleSendTextButtonAction() {
        String newMessage = messageTextField.getText();
        if (!newMessage.isEmpty()) {
            Util.sendMessage(contactName, new TextMessage(newMessage));
            messageTextField.clear();
            List<Message> updatedMessages = Util.fetchConversationMessages(contactName);
            messageListView.getItems().setAll(updatedMessages);
        }
    }
    @FXML
    private void handleSendMediaButtonAction() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Media File");
        File selectedFile = fileChooser.showOpenDialog(messageListView.getScene().getWindow());
        if (selectedFile != null) {
            Util.sendMessage(contactName, new MediaMessage(selectedFile.toURI().toString()));
            List<Message> updatedMessages = Util.fetchConversationMessages(contactName);
            messageListView.getItems().setAll(updatedMessages);
        }
    }
    @FXML
    private ListCell<Message> messageCellFactory(ListView<Message> listView) {
        return new ListCell<>() {
            @Override
            protected void updateItem(Message message, boolean empty) {
                super.updateItem(message, empty);
                if (empty || message == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    setText(null);
                    setGraphic(message.getGraphic());
                }
            }
        };
    }
}
