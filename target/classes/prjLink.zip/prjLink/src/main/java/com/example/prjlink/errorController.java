import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

import java.util.List;

public class errorController {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ImageView errorImageView;

    @FXML
    private VBox errorVBox;

    @FXML
    private Label errorTitleLabel;

    @FXML
    private ListView<String> errorListView;

    @FXML
    private Button backButton;

    @FXML
    private void handleBackButtonAction() {
        Util.switchToHomePage();
    }
    public void setErrorMessages(List<String> errorMessages) {
        errorListView.getItems().addAll(errorMessages);
    }
}
