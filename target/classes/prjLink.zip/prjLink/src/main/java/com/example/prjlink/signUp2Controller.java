import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import java.io.File;

public class singUp2Controller{

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private VBox profileVBox;

    @FXML
    private Label profileTitleLabel;

    @FXML
    private Label profileSubtitleLabel;

    @FXML
    private TextArea userBioTextArea;

    @FXML
    private TextField skillsTextField;

    @FXML
    private TextArea projectsTextArea;

    @FXML
    private TextArea experienceTextArea;

    @FXML
    private HBox cvVideoHBox;

    @FXML
    private TextField cvVideoTextField;

    @FXML
    private Button browseButton;

    @FXML
    private Button saveProfileButton;

    @FXML
    private void handleBrowseButtonAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose CV Video File");
        File selectedFile = fileChooser.showOpenDialog(anchorPane.getScene().getWindow());

        if (selectedFile != null) {
            cvVideoTextField.setText(selectedFile.getAbsolutePath());
        }
    }
    @FXML
    private void handleSaveProfileButtonAction(ActionEvent event) {
        String userBio = userBioTextArea.getText();
        String skills = skillsTextField.getText();
        String projects = projectsTextArea.getText();
        String experience = experienceTextArea.getText();
        String cvVideoPath = cvVideoTextField.getText();

        boolean fieldsValid = Util.validateProfileFields(userBio, skills, projects, experience, cvVideoPath);
        if (fieldsValid) {
            boolean switchToErrorPage = false;

            if (switchToErrorPage) {
                Util.switchToErrorPage();
            }
            else {
                Util.switchToNextPage();
            }
        } else {
            Util.switchToErrorPage();
                }
    }
}

