import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.List;

public class NewConversationPageController {

    @FXML
    private ListView<String> contactListView;

    @FXML
    private Button startConversationButton;

    public void initialize() {
        List<String> allContacts = Util.fetchAllContacts();
        contactListView.getItems().addAll(allContacts);
    }

    @FXML
    private void handleStartConversationButtonAction() {
        String selectedContact = contactListView.getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            Util.startConversation(selectedContact);
            Util.switchToChatPage(selectedContact);
        }
    }
}
