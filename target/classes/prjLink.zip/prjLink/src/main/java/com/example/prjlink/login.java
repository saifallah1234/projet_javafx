import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class loginController {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextField usernameField;

    @FXML
    private Label usernameErrorLabel;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label passwordErrorLabel;

    @FXML
    private Button signInButton;

    @FXML
    private Hyperlink signUpLink;

    @FXML
    private void handleSignInButtonAction(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();
        boolean credentialsValid = Util.validateCredentials(username, password);

        if (credentialsValid) {
            Util.switchToPage(signInButton, "#");
        } else {
            Util.switchToErrorPage();
        }
    }
    @FXML
    private void handleSignUpLinkAction(ActionEvent event) {
        Util.switchToPage(signUpLink, "C:\\Users\\bechi\\Downloads\\prjLink\\src\\main\\resources\\com\\example\\prjlink\\signup1.fxml");
    }
}
